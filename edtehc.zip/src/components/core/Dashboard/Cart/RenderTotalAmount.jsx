import React from 'react'

function RenderTotalAmount() {
  return (
    <div>RenderTotalAmount</div>
  )
}

export default RenderTotalAmount