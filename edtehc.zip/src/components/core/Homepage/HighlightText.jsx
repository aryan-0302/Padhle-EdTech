import React from 'react'

function HighlightText({text}) {
  return (
    <span className='font-bold text-richblue-100'>
        {text}
    </span>
  )
}

export default HighlightText