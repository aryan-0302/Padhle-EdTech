import React from 'react'

function ViewCourse() {
  return (
    <div>ViewCourse</div>
  )
}

export default ViewCourse