import React from 'react'

function Error() {
  return (
    <div className='flex justify-center items-center text-3xl'>Error-404 Not Found</div>
  )
}

export default Error